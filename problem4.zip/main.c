#include<stdio.h>
int main()
{
    printf("enter the size of array");
    int n,m;
    scanf("%d",&n);
    
    printf("enter the number");
    scanf("%d",&m);

    int i,a[n],temp;
    int b[n];
        printf("enter the array1\n");

    for(i=0;i<n;i++)
    {
    scanf("%d",&a[i]);
    }
        printf("enter the array2\n");

     for(i=0;i<n;i++)
    {
    scanf("%d",&b[i]);
    }
    
  
    
    for(i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(a[i]+b[j]==m)
            {
                printf("%d %d\n",a[i],b[j]);
            }
 }
}
}