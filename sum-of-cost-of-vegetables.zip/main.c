#include<stdio.h>
#include<string.h>
int main()
{
int n;
char a[4][10]={"tomato","brinjal","onion","potato"};
int b[4]={30,20,35,25};
printf("count of vegetables ");
scanf("%d",&n);
char name[4][10];
printf("enter the vegetable name");
for(int i=0;i<n;i++)
{
scanf("%s",&name[i]);
}
int sum=0;
for(int i=0;i<n;i++)
{
for(int j=0;j<4;j++)
{
if(strcmp(name[i],a[j])==0)
{
sum = sum+b[j];
}
}
}
printf("%d",sum);
}
