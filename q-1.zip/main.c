#include<stdio.h>
int main()
{
  int t, k, l, m;
  scanf("%d", & t);
  while (t--)
  {
    scanf("%d%d%d", & k, & l, & m);
    if (m > k && m > l)
      printf("-1\n");
    else if (m % gcd(k, l) != 0)
      printf("-1\n");
    else if (m == k || m == l)
      printf("1\n");
    else
      printf("%d\n", min(pour(k, l, m), pour(l, k, m)));
  }
  return 0;
}
int min(int k,int l)
{
	if(k<l)
	return l;
	else return l;
}

int pour(int A, int B, int C)
{
  int move = 1, k= A, l = 0, tfr;
  while (k != C && l != C)
  {
    tfr = min(k, B - l);
    l += tfr;
    k -= tfr;
    move++;
    if (k == C || l == C)
      break;
    if (k == 0)
    {
      k = A;
      move++;
    }
    if (l == B)
    {
      l = 0;
      move++;
    }
  }
  return move;
  }

int gcd(int k, int l)
{
  if (l == 0)
    return k;
  return gcd(l, k % l);
}
