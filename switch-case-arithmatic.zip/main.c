#include <stdio.h>

int main()
{
    int a,b;
char i;
printf("Enter your choice + - * / \n");
scanf("%c",&i);
printf("enter the value of a and b \n");
scanf("%d %d",&a,&b);

 switch(i)
 {
     case '+':
     printf("%d ",a+b);
     break;
      case '-':
    printf("%d ",a-b);
     break;
      case '*':
    printf("%d ",a * b);
     break;
      case '/':
    printf("%d ",a/b);
     break;
     default:
     printf("Enter correct choice");
     break;
 }
    return 0;
}

