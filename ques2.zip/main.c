
#include <stdio.h>

int main()
{
 float T,H,A,d;
 printf("Enter the total no of apple bought by hema and anni\n");
 scanf("%f",&T);
 printf(" enter the difference between two of them");
  scanf("%f",&d);

 
 H= (T/2)+ (d/2);
 A= (T/2)-(d/2);
 printf("the answer said by jessy\n ");
 printf("%.2f \n%.2f",H,A);
    return 0;
}
