#include <stdio.h>

int main()
{
    int a=10;
    int b=30;
    int ans =a>b? b:a;
    printf ("%d",ans);
}
