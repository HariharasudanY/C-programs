#include <stdio.h>
#include<string.h>
void main()
{
	char veg[10];
	printf("enter the vegetable:");
	
  scanf("%s",&veg);
  char a[4][10]={"Tomato","brinjal","onion","potato"};
  int b[4]={30,20,35,25};
  for(int i=0;i<4;i++)
  {
  	if(strcmp(veg,a[i])==0)
  	printf("%d ",b[i]);
  }
  
  
}