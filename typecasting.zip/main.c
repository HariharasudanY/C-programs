#include <stdio.h>

int main()
{
    int a=10;
    float b;
    b=(float)a;
    printf("%f",b);

    return 0;
}
