#include <stdio.h>
int fact(int r);
int main()
{
  int num,rem,sum=0,d;
  scanf("%d",&num);
  d=num;
  while(num>0)
  {
      rem=num%10;
      num=num/10;
      int f= fact(rem);
      sum=sum+f;
      
  }
  if(sum==d)
  {
      printf("%d is a strong number.",d);
  }
  else
  {
      printf("%d is not a strong number.",d);
  }
}
int fact(int r)
{
    int i,mul=1;
    for(i=1;i<=r;i++)
    {
        mul=mul* i;
    }
    return mul;
}
