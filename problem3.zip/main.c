#include<stdio.h>
int main()
{
    printf("enter the size of array");
    int n,m,flag=0;
    scanf("%d",&n);
    
    int a[n],b[n],i,j,temp;
        printf("1st array\n");

    
    for(i=0;i<n;i++)
    {
    scanf("%d",&a[i]);
    }
    
            printf("2nd array\n");

      
    for(i=0;i<n;i++)
    {
    scanf("%d",&b[i]);
    }
    
    
    
    
    for(i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(a[i]<a[j])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
            if(b[i]<b[j])
            {
                temp=b[i];
                b[i]=b[j];
                b[j]=temp;
            }
        }
    }
    
  
      printf("\noutput");

       for(i=0;i<n;i++)
    {
            if(a[i]==b[i])
            {
             flag=1;
            }
            else
            {
            flag=0;
            break;
            }
    } 
    
    if(flag==1)
    {
      printf("1");
    }
    else
    {
   printf("0");

}

}