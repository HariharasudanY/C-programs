#include<stdio.h>
#include<string.h>
int main()
{
	char name[7];
       printf("Enter the name: ");
       scanf("%s",&name);
       char a[3][7]={"hari","nithish","dhinesh"};
       int b[3]={19,33,16};
       for(int i=0;i<3;i++)
       {
       	if(strcmp(name,a[i])==0)
       	{
       		printf("%d",b[i]);
               }
        }
}