#include <stdio.h>
#include <string.h>
int main()
    {
        char str[25],ch;
        int i,len,j;
        int count=0;
         printf("enter a character");
        scanf("%c",&ch);
        printf("enter a string\n");
        scanf("%s",str);
        len=strlen(str);
        for(i=0;i<len;i++)
        {
            
           if(str[i]==ch)
    {    
          if(str[i] == ch)
        {
            for(j=i; j<len; j++)
            {
                str[j] = str[j+1];
            }
            len--;
            i--;
            break;
        }
    }    
        
        }
        printf("String after removing '%c': %s", ch, str);
    }

