#include <stdio.h>

int main()
{
   char c[70];
     puts("enter a name");
   gets(c);
   printf("%s",c);

    return 0;
}
